# Subdomain Generator 🚀

## Cara Deploy
1. Upload folder ini ke GitHub (public repo).
2. Import ke Vercel.
3. Tambahkan Environment Variables:
   - `CF_API_TOKEN`
   - `CF_ZONE_ID`
   - `CF_DOMAIN`
4. Klik **Deploy** ✅

## Gunakan
Akses URL: `https://<project>.vercel.app`, lalu isi form buat subdomain baru.